{{/*
Expand the name of the chart.
*/}}
{{- define "rustfs-operator.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "rustfs-operator.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "rustfs-operator.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "rustfs-operator.labels" -}}
helm.sh/chart: {{ include "rustfs-operator.chart" . }}
{{ include "rustfs-operator.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- with .Values.commonLabels }}
{{ toYaml . }}
{{- end }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "rustfs-operator.selectorLabels" -}}
app.kubernetes.io/name: {{ include "rustfs-operator.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "rustfs-operator.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "rustfs-operator.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Namespace
*/}}
{{- define "rustfs-operator.namespace" -}}
{{- default .Release.Namespace .Values.namespace }}
{{- end }}

{{/*
Name of the namespaced Role used by STS auto TLS.
*/}}
{{- define "rustfs-operator.stsTlsRoleName" -}}
{{- printf "%s-sts-tls" (include "rustfs-operator.fullname" .) | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Optional Service ipFamilyPolicy / ipFamilies from values.network.
*/}}
{{- define "rustfs-operator.serviceNetwork" -}}
{{- $network := default dict .Values.network -}}
{{- if $network.ipFamilyPolicy }}
ipFamilyPolicy: {{ $network.ipFamilyPolicy }}
{{- end }}
{{- if $network.ipFamilies }}
ipFamilies:
{{- range $network.ipFamilies }}
- {{ . }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create the name of the console service account to use
*/}}
{{- define "rustfs-operator.consoleServiceAccountName" -}}
{{- if .Values.console.serviceAccount.create }}
{{- default (printf "%s-console" (include "rustfs-operator.fullname" .)) .Values.console.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.console.serviceAccount.name }}
{{- end }}
{{- end }}
